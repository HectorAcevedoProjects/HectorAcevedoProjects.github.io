export * from './markdown-it-vue'
import { MarkdownItVue } from './markdown-it-vue'
export default MarkdownItVue